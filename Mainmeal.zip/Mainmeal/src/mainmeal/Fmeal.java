
package mainmeal;

public class Fmeal {
    private int pos = 0;
    private final String M_HandP [][]= {{"5'2","115-121"},{"5'3","120-129"},{"5'4","125-137"},{"5'5","130-145"},{"5'6","135-153"},
                            {"5'7","140-161"},{"5'8","145-169"},{"5'9","150-177"},{"5'10","155-185"},{"5'11","160-193"},
                            {"6'0","165-201"},{"6'1","170-209"},{"6'2","175-217"},{"6'3","180-225"},{"6'4","185-233"}};
    private final int M_HandP1 [][] ={{115,121},{120,129},{125,137},{130,145},{135,153},
                                {140,161},{145,169},{150,177},{155,185},{160,193},
                                {165,201},{170,209},{175,217},{180,225},{185,233}};
    private final String F_HandP [][]= {{"4'11","93-100"},{"5'0","98-102"},{"5'1","103-106"},{"5'2","106-112"},{"5'3","109-118"},
                            {"5'4","112-124"},{"5'5","115-130"},{"5'6","118-136"},{"5'7","121-142"},{"5'8","124-148"},
                            {"5'9","127-153"},{"5'10","130-158"},{"5'11","133-163"},{"6'0","136-168"},{"6'1","139-173"}};
    private final int F_HandP1 [][] ={{93,100},{98,102},{103,106},{106,112},{109,118},
                                {112,124},{115,130},{118,136},{121,142},{124,148},
                                {127,153},{130,158},{133,163},{136,168},{139,173}};
    private final String WieghtGain ="Breakfast:"
            + "\n\t1 ½ cup rice or veggies \n\t 2 palm size fish or chicken"
            + "\nSnack at 9am"
            + "\n\t1 banana or apple \n\t 1 glass of water"
            + "\nLunch:"
            + "\n\t1 ½ cup rice or veggies \n\t2 palm size fish or chicken"
            + "\nSnack at 3pm"
            + "\n\t1 banana or apple \n\t1 glass of water"
            + "\nDinner:"
            + "\n\t1 ½ cup rice or veggies \n\t2 palm size fish or chicken";
    private final String WieghtLoss ="Breakfast:"
            + "\n\t1 cup rice or veggies \n\t1 palm size fish or chicken"
            + "\nLunch:"
            + "\n\t1 cup rice or veggies \n\t1 palm size fish or chicken"
            + "\nDinner:"
            + "\n\t½ cup rice or veggies \n\t1 palm size fish or chicken";
    Fmeal(){}
    int getpos(){return pos;};
    String getWieghtGain(){
        return WieghtGain;
    }
    String getWieghtLoss(){
        return WieghtLoss;
    }
    String[][] getM_HandP(){
        return M_HandP;
    }
    String[][] getF_HandP(){
        return F_HandP;
    }
    String getIdealWeight(String gender){
        if(gender == "Male"){
            return M_HandP[pos][1];
        }
        else if(gender == "Female"){
            return F_HandP[pos][1];
        }
        return "Error!";
    }
    String getGainOrLoss(String height,int weight,String gender){
        if(gender=="Male"){
            for(int i=0;i<M_HandP.length;i++){
                if(height.equals(M_HandP[i][0]) && M_HandP1[i][0] < weight && weight < M_HandP1[i][1] || M_HandP1[i][0] == weight || M_HandP1[i][1] == weight){
                    pos = 16;return "No Meal Recommendation.\nYour Weight is Normal with your Height";
                }
                if(height.equals(M_HandP[i][0])  && M_HandP1[i][1] < weight){
                    pos = i;return getWieghtLoss();
                }
                if(height.equals(M_HandP[i][0])  && weight < M_HandP1[i][0]){
                    pos = i;return getWieghtGain();
                }
            }
        }
        else if(gender=="Female"){
            for(int i=0;i<F_HandP.length;i++){
                if(height.equals(F_HandP[i][0]) && F_HandP1[i][0] < weight && weight < F_HandP1[i][1] || F_HandP1[i][0] == weight || F_HandP1[i][1] == weight){
                    pos = 16;return "No Meal Recommendation.\nYour Weight is Normal with your Height";
                }
                if(height.equals(F_HandP[i][0]) && F_HandP1[i][1] < weight){
                    pos = i;return getWieghtLoss();
                }
                if(height.equals(F_HandP[i][0]) && weight < F_HandP1[i][0]){
                    pos = i;return getWieghtGain();
                }
            }
        }
        return "Error!";
    }
}