package mainmeal;

import javax.swing.*;
import java.awt.event.*;

public class Mainmeal extends JFrame implements ActionListener,KeyListener{
    Fmeal Mdata = new Fmeal();
    String [] Gender = {"Male","Female"};
    String [] Thead = {"Hieght","Pounds"};
    JTextField txtW, txtH;
    JLabel lblweight, lblAge,lblE,lblmale,lblfemale,lblgender,lblgender1,MH,MP,FH,FP,lblideal;
    JFrame frame;
    JButton bent, bres;
    JTextArea display;
    JComboBox dd;
    JTable Mchart,Fchart;
    
    
    public Mainmeal() {
        
        Mchart = new JTable(Mdata.getM_HandP(),Thead);
        Fchart = new JTable(Mdata.getF_HandP(),Thead);
        dd = new JComboBox(Gender);
        MH = new JLabel(Thead[0]);
        MP = new JLabel(Thead[1]);
        FH = new JLabel(Thead[0]);
        FP = new JLabel(Thead[1]);
        lblgender = new JLabel("Gender");
        lblgender = new JLabel("Gender:");
        lblmale = new JLabel(Gender[0]);
        lblfemale = new JLabel(Gender[1]);
        lblideal = new JLabel();
    	lblweight = new JLabel("Enter Weight in Lbs:");
    	lblAge = new JLabel("Enter Height in Ft:");
    	lblE = new JLabel("");
    	txtW = new JTextField();
    	txtH = new JTextField();
    	display = new JTextArea();
    	bent = new JButton("Enter");
    	bres = new JButton("Reset");
    	
        
    	setSize(800,500);
        setVisible(true);
        setTitle("Meal Plan by: Pams");
        setLayout(null);
        setResizable(false);
        setLocationRelativeTo(null);

        
        
        add(MH);
        MH.setBounds(380,35,100,25);
        add(MP);
        MP.setBounds(455,35,100,25);
        add(lblmale);
        lblmale.setBounds(440,320,100,25);
        add(Mchart);
        Mchart.setBounds(380, 60, 150, 240);
        Mchart.setEnabled(false);
        
        add(FH);
        FH.setBounds(600,35,100,25);
        add(FP);
        FP.setBounds(675,35,100,25);
        add(lblfemale);
        lblfemale.setBounds(660,320,100,25);
        add(Fchart);
        Fchart.setBounds(600, 60, 150, 240);
        Fchart.setEnabled(false); 
        
        add(lblideal);
        lblideal.setBounds(380, 380, 350, 20);
        
        add(dd);
        dd.setBounds(190, 320, 120, 25);
        
        add(lblgender);
        lblgender.setBounds(70, 320, 180, 30);
        
        add(lblAge);
        lblAge.setBounds(70,350,180,30);
        
        add(lblweight);
        lblweight.setBounds(70,380,180,30);
        
        add(txtH);
   	txtH.setBounds(190,350,120,25);
        
   	 	
   	add(txtW);
   	txtW.setBounds(190,380,120,25);
        txtW.addKeyListener(this);
        
        add(display);
        display.setBounds(50,20,300, 280);
        display.setEditable(false);
        
        
        add(bent);
        bent.setBounds(200,430,80,30);
        
        add(bres);
        bres.setBounds(100,430,80,30);
        
        add(lblE);
        lblE.setBounds(0,0,500,500);
        
        //add(lblA);
        
        bent.addActionListener(this);
        bres.addActionListener(this);
    }
    @Override
    public void actionPerformed (ActionEvent e){
        if(e.getSource().equals(bent)){
            if(txtW.getText().isEmpty() != true){
                String result = Mdata.getGainOrLoss(txtH.getText(),Integer.parseInt(txtW.getText()), dd.getSelectedItem().toString());
                if(result != "Error!"){
                    lblideal.setText("");
                    display.setText(result);
                    String result1 = restext(result);
                    if(dd.getSelectedItem().toString()=="Male" && Mdata.getpos()!=16){
                        lblideal.setText("Sir! "+result1+" You're Ideal Weight is "+Mdata.getIdealWeight(dd.getSelectedItem().toString()));
                    }
                    else if(dd.getSelectedItem().toString()=="Female" && Mdata.getpos()!=16){
                        lblideal.setText("Maam! "+result1+" You're Ideal Weight is "+Mdata.getIdealWeight(dd.getSelectedItem().toString()));
                    }
                }
                else{
                    JOptionPane.showMessageDialog(rootPane, "You Input Wrong Height or Weight");
                    txtH.setText("");txtW.setText("");
                }
            }
            else{
                JOptionPane.showMessageDialog(rootPane, "You Input Wrong Height or Weight");
                txtH.setText("");txtW.setText("");
            }
        }
        if(e.getSource().equals(bres)){
            reset();
        }
    }
    @Override
    public void keyTyped(KeyEvent e) {
        if(e.getSource() == txtW){
            if(!(Character.isDigit(e.getKeyChar())) || e.getKeyChar()== KeyEvent.VK_BACK_SPACE){
                e.consume();
            }
        }
    }
    @Override
    public void keyPressed(KeyEvent e) {
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
    public String restext(String result){
        if(result == Mdata.getWieghtGain()){
            return "You Lack Nutrients";
        }
        else{
            return "You Gain More Weight";
        }
    }
    public void reset(){
        display.setText("");txtH.setText("");
        lblideal.setText("");txtW.setText("");
    }
 
    public static void main(String[] args) {
       Mainmeal MM = new Mainmeal();
        MM.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
