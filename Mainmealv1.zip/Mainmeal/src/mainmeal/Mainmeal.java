package mainmeal;

import javax.swing.*;
import java.awt.event.*;

public class Mainmeal extends JFrame implements ActionListener,KeyListener{

    public static void main(String[] args) {
        Fmeal Mdata = new Fmeal();
    
        String [] Gender = {"Male","Female"};
        String [] Thead = {"Hieght","Pounds"};
        JTextField txtW, txtH;
        JLabel lblweight, lblAge,lblE,lblmale,lblfemale,lblgender,lblgender1,MH,MP,FH,FP,lblideal;
        JFrame frame;
        JButton bent, bres;
        JTextArea display;
        JComboBox dd;
        JTable Mchart,Fchart;
       
        Mchart = new JTable(Mdata.getM_HandP(),Thead);
        Fchart = new JTable(Mdata.getF_HandP(),Thead);
        dd = new JComboBox(Gender);
        MH = new JLabel(Thead[0]);
        MP = new JLabel(Thead[1]);
        FH = new JLabel(Thead[0]);
        FP = new JLabel(Thead[1]);
        lblgender = new JLabel("Gender");
        lblgender = new JLabel("Gender:");
        lblmale = new JLabel(Gender[0]);
        lblfemale = new JLabel(Gender[1]);
        lblideal = new JLabel();
    	lblweight = new JLabel("Enter Weight in Lbs:");
    	lblAge = new JLabel("Enter Height in Ft:");
    	lblE = new JLabel("");
    	txtW = new JTextField();
    	txtH = new JTextField();
    	display = new JTextArea();
    	bent = new JButton("Enter");
    	bres = new JButton("Reset");
        frame = new JFrame();
    	       
    	frame.setSize(800,500);
        frame.setVisible(true);
        frame.setTitle("Meal Plan by: Pams");
        frame.setLayout(null);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.add(MH);
        MH.setBounds(380,35,100,25);
        frame.add(MP);
        MP.setBounds(455,35,100,25);
        frame.add(lblmale);
        lblmale.setBounds(440,320,100,25);
        frame.add(Mchart);
        Mchart.setBounds(380, 60, 150, 240);
        Mchart.setEnabled(false);
        
        frame.add(FH);
        FH.setBounds(600,35,100,25);
        frame.add(FP);
        FP.setBounds(675,35,100,25);
        frame.add(lblfemale);
        lblfemale.setBounds(660,320,100,25);
        frame.add(Fchart);
        Fchart.setBounds(600, 60, 150, 240);
        Fchart.setEnabled(false); 
        
        frame.add(lblideal);
        lblideal.setBounds(380, 380, 350, 20);
        
        frame.add(dd);
        dd.setBounds(190, 320, 120, 25);
        
        frame.add(lblgender);
        lblgender.setBounds(70, 320, 180, 30);
        
        frame.add(lblAge);
        lblAge.setBounds(70,350,180,30);
        
        frame.add(lblweight);
        lblweight.setBounds(70,380,180,30);
        
        frame.add(txtH);
   	txtH.setBounds(190,350,120,25);
        
   	 	
   	frame.add(txtW);
   	txtW.setBounds(190,380,120,25);
        
        frame.add(display);
        display.setBounds(50,20,300, 280);
        display.setEditable(false);
        
        
        frame.add(bent);
        bent.setBounds(200,430,80,30);
        
        frame.add(bres);
        bres.setBounds(100,430,80,30);
        
        frame.add(lblE);
        lblE.setBounds(0,0,500,500);
        

        bent.addActionListener(new ActionListener(){@Override
        public void actionPerformed(ActionEvent e){
            if(txtW.getText().isEmpty() != true){
                String result = Mdata.getGainOrLoss(txtH.getText(),Integer.parseInt(txtW.getText()), dd.getSelectedItem().toString());
                if(result != "Error!"){
                    lblideal.setText("");
                    display.setText(result);
                    String result1 = "";
                    if(result == Mdata.getWieghtGain()){
                        result1 = "You Lack Nutrients";
                    }
                    else{
                        result1 = "You Gain More Weight";
                    }
                     
                    if(dd.getSelectedItem().toString()=="Male" && Mdata.getpos()!=16){
                        lblideal.setText("Sir! "+result1+" You're Ideal Weight is "+Mdata.getIdealWeight(dd.getSelectedItem().toString()));
                    }
                    else if(dd.getSelectedItem().toString()=="Female" && Mdata.getpos()!=16){
                        lblideal.setText("Maam! "+result1+" You're Ideal Weight is "+Mdata.getIdealWeight(dd.getSelectedItem().toString()));
                    }
                }
                else{
                    JOptionPane.showMessageDialog(frame, "You Input Wrong Height or Weight");
                    txtH.setText("");txtW.setText("");
                }
            }
            else{
                JOptionPane.showMessageDialog(frame, "You Input Wrong Height or Weight");
                txtH.setText("");txtW.setText("");
            }
        }});
        
        bres.addActionListener(new ActionListener(){@Override
        public void actionPerformed(ActionEvent e){
            display.setText("");txtH.setText("");
            lblideal.setText("");txtW.setText("");
        }});
        
//        txtW.addKeyListener(new KeyListener(){@Override
//            public void keyTyped(KeyEvent e) {
//            if(e.getSource() == txtW){
//                if(!(Character.isDigit(e.getKeyChar())) || e.getKeyChar()== KeyEvent.VK_BACK_SPACE){
//                    e.consume();
//                    }
//                }
//            }
//            @Override
//            public void keyPressed(KeyEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//            }
//
//            @Override
//            public void keyReleased(KeyEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//            }
//
//
//            
//        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
